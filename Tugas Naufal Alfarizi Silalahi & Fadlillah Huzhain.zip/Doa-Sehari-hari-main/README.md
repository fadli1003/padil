# Doa-Sehari-hari
Membuat Aplikasi Doa Sehari-hari (Lengkap)

# Tutorial Build with Android Studio
https://youtu.be/RxgUZb_WtHM

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2021/02/Tutorial-Membuat-Aplikasi-Doa-Sehari-hari-dengan-Android-Studio.html

<img src="https://1.bp.blogspot.com/-8EYuXHDYvGg/YCpjMJHNMGI/AAAAAAAAHv4/MVpIPbv3zWoxYOFrDWS9MZbWspRZQWPZgCLcBGAsYHQ/s1280/Tutorial%2BMembuat%2BAplikasi%2BDoa%2BSehari-hari%2Bdengan%2BAndroid%2BStudio.png" data-canonical-src="https://1.bp.blogspot.com/-8EYuXHDYvGg/YCpjMJHNMGI/AAAAAAAAHv4/MVpIPbv3zWoxYOFrDWS9MZbWspRZQWPZgCLcBGAsYHQ/s1280/Tutorial%2BMembuat%2BAplikasi%2BDoa%2BSehari-hari%2Bdengan%2BAndroid%2BStudio.png" style="max-width:100%;">


****If you use the Source Code, please make sure to credit and backlink to [Azhar Rivaldi](https://rivaldi48.blogspot.com/)***

## 📄 License

```
Copyright (C) Azhar Rivaldi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

```
