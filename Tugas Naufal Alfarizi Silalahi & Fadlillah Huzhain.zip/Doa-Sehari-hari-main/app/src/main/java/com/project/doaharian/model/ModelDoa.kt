package com.project.doaharian.model

/**
 * Created by Azhar Rivaldi on 05-02-2021
 */

class ModelDoa {
    var strId: String? = null
    var strTitle: String? = null
    var strArabic: String? = null
    var strLatin: String? = null
    var strTranslation: String? = null
}